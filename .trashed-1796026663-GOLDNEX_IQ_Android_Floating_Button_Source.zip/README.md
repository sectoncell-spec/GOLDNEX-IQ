# GOLDNEX IQ Android floating shortcut — source project

This is an Android Studio source project for a draggable floating GOLDNEX shortcut.

## What it does
- Requests Android's **Display over other apps** permission.
- Starts a foreground service with a draggable circular `G` bubble.
- Tapping the bubble opens the GOLDNEX app activity.
- Includes a manual **Open IQ Option** button that tries known package IDs; if the installed app uses another package ID, open it manually from the app drawer.

## Safety and scope
The bubble is a launcher shortcut only. It does not inspect IQ Option screens, inject taps, click BUY/SELL, execute trades, or connect to a broker. No automatic trading is implemented.

## Build
1. Open this folder in Android Studio (Giraffe or newer; Android SDK 35 installed).
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated debug APK on your Android phone.
5. Open GOLDNEX IQ, grant **Display over other apps**, then tap **Start floating GOLDNEX button**.

This source project does not include a prebuilt APK. Android Studio is required to compile it.
