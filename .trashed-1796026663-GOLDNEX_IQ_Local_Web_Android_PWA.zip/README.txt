# GOLDNEX IQ — Local Web + Android PWA

## What this build does
- Runs locally in a browser and can be installed on Android as a PWA.
- Displays a simulated EUR/USD price chart, EMA 9, EMA 21 and RSI 14.
- Includes a virtual paper account and simulated BUY/SELL positions.
- Supports 1, 5 and 10 second simulated-feed intervals.

## Important limitation
This build uses randomly generated demo prices. It does NOT display live Forex quotes and does NOT connect to IQ Option or any broker. Paper positions are virtual only; no real orders or money are involved.

## Run locally on Android
1. Extract this ZIP into a folder in your phone.
2. Open the folder in an app that can run a local Python server (for example, Pydroid 3 with its terminal).
3. In that folder, run:
   `python -m http.server 8000`
4. Open Chrome and visit:
   `http://127.0.0.1:8000`

## Install on Android
For PWA installation, serve the app from `localhost` as above. In Chrome, open the app page, tap the three-dot menu, then choose **Add to Home screen** or **Install app** if offered.
The service worker requires localhost or HTTPS; opening index.html directly as a file will not enable offline PWA installation.

## Web hosting
You can also upload the extracted files to any static HTTPS host. Then open the hosted URL in Chrome and choose Install app / Add to Home screen.

## About APK
This package is an installable PWA, not a compiled native APK. It gives an app-like home-screen experience without requiring an Android build toolchain.
