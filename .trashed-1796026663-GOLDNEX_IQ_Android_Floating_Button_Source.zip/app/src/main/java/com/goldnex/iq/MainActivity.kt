package com.goldnex.iq

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(android.graphics.Color.rgb(8, 14, 25))
        }
        val title = TextView(this).apply {
            text = "GOLDNEX IQ"
            textSize = 25f
            setTextColor(android.graphics.Color.rgb(230, 189, 102))
        }
        val desc = TextView(this).apply {
            text = "Floating shortcut for your educational Forex dashboard"
            textSize = 14f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(0, pad / 2, 0, pad)
        }
        val permission = Button(this).apply { text = "1. Allow display over other apps" }
        val start = Button(this).apply { text = "2. Start floating GOLDNEX button" }
        val stop = Button(this).apply { text = "Stop floating button" }
        val openIq = Button(this).apply { text = "Open IQ Option" }
        val note = TextView(this).apply {
            text = "\nThe floating button is a shortcut only. It opens the GOLDNEX dashboard. It does not read IQ Option's screen, tap trading controls, or place trades. If the IQ Option app cannot be found, open it manually."
            textSize = 12f
            setTextColor(android.graphics.Color.LTGRAY)
        }
        layout.addView(title); layout.addView(desc)
        layout.addView(permission); layout.addView(start); layout.addView(stop); layout.addView(openIq); layout.addView(note)
        setContentView(layout)

        permission.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else Toast.makeText(this, "Overlay permission is already enabled", Toast.LENGTH_SHORT).show()
        }
        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow display over other apps first", Toast.LENGTH_LONG).show()
            } else {
                val intent = Intent(this, FloatingButtonService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
                Toast.makeText(this, "Floating button started", Toast.LENGTH_SHORT).show()
            }
        }
        stop.setOnClickListener { stopService(Intent(this, FloatingButtonService::class.java)) }
        openIq.setOnClickListener { launchIqOption() }
    }

    private fun launchIqOption() {
        // Package IDs can vary by IQ Option app version/region. If this package is not present,
        // Android shows a helpful message and the user can open IQ Option manually.
        val candidates = listOf("com.iqoption", "com.iqoption.client")
        for (pkg in candidates) {
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                startActivity(launch)
                return
            }
        }
        Toast.makeText(this, "IQ Option app not detected. Please open it from your app drawer.", Toast.LENGTH_LONG).show()
    }
}
